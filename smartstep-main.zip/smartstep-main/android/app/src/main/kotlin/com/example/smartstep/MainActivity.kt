package com.example.smartstep

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
